# Lime's Visuals – TargetESP

Native mod for **LeviLaunchroid** (Minecraft Bedrock **1.26.60.4**).

When you hit a player/entity, configurable TargetESP particle styles play around the target.

## Styles (Mod Menu toggles)

- Nova
- Wild
- Nursultan Diamond
- Nursultan Scanner
- Ghosts (Client)
- Ghosts (Catlean)
- Wexside Swords
- Sims Crystal
- Jello
- Rockstar Crystals
- Rockstar Chains
- HitBubble

Also:
- Only Players
- Only When I Hit
- Intensity / Particle Count

## Build

GitHub Actions builds the `.levipack` on every push.

## Status

- v0.2.0 – Mod Menu + config + skeleton hooks
- Next: real hit detection + particle spawn for 1.26.60.4
