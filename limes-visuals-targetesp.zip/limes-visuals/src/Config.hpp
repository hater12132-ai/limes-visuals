#pragma once

#include <cstdint>
#include <string>

// Each style can be toggled independently for now.
// Later we can force single-select if you prefer.
struct ModConfig {
    int  version = 1;

    bool masterEnabled = true;

    // Styles (match reference pack names)
    bool styleNova              = true;
    bool styleWild              = false;
    bool styleNursultanDiamond  = false;
    bool styleNursultanScanner  = false;
    bool styleGhostsClient      = false;
    bool styleGhostsCatlean     = false;
    bool styleWexsideSwords     = false;
    bool styleSimsCrystal       = false;
    bool styleJello             = false;
    bool styleRockstarCrystals  = false;
    bool styleRockstarChains    = false;
    bool styleHitBubble         = false;

    // Who triggers the effect
    bool onlyPlayers            = true;   // false = any entity
    bool onlyWhenIHit           = true;   // false = any damage on target

    // Visual tuning
    int  intensity              = 100;    // 0-100
    int  particleCount          = 12;     // rough amount
};
