#include "TargetESP.hpp"

#include <pl/memory/Hook.hpp>

#include <android/log.h>
#include <atomic>
#include <mutex>

#define LOG_TAG "LimesVisuals"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace targetesp {

namespace {

RuntimeState g_state;
std::atomic<bool> g_installed{false};

// Placeholder for future signatures (1.26.60.4)
// We will fill these once we resolve Actor::hurt / attack related symbols.
pl::memory::HookHandle g_hookHurt;

} // anonymous

RuntimeState& state() { return g_state; }

void applyConfig(const ModConfig& cfg) {
    g_state.masterEnabled.store(cfg.masterEnabled);

    g_state.styleNova.store(cfg.styleNova);
    g_state.styleWild.store(cfg.styleWild);
    g_state.styleNursultanDiamond.store(cfg.styleNursultanDiamond);
    g_state.styleNursultanScanner.store(cfg.styleNursultanScanner);
    g_state.styleGhostsClient.store(cfg.styleGhostsClient);
    g_state.styleGhostsCatlean.store(cfg.styleGhostsCatlean);
    g_state.styleWexsideSwords.store(cfg.styleWexsideSwords);
    g_state.styleSimsCrystal.store(cfg.styleSimsCrystal);
    g_state.styleJello.store(cfg.styleJello);
    g_state.styleRockstarCrystals.store(cfg.styleRockstarCrystals);
    g_state.styleRockstarChains.store(cfg.styleRockstarChains);
    g_state.styleHitBubble.store(cfg.styleHitBubble);

    g_state.onlyPlayers.store(cfg.onlyPlayers);
    g_state.onlyWhenIHit.store(cfg.onlyWhenIHit);
    g_state.intensity.store(cfg.intensity);
    g_state.particleCount.store(cfg.particleCount);
}

void onEntityHit(float x, float y, float z, bool isPlayer) {
    if (!g_state.masterEnabled.load(std::memory_order_relaxed))
        return;

    if (g_state.onlyPlayers.load(std::memory_order_relaxed) && !isPlayer)
        return;

    // For now just log which styles would play.
    // Next step: call Level particle spawn / trigger resource-pack effects.
    LOGI("TargetESP hit at (%.2f, %.2f, %.2f) isPlayer=%d", x, y, z, (int)isPlayer);

    if (g_state.styleNova.load())             LOGI("  -> Nova");
    if (g_state.styleWild.load())             LOGI("  -> Wild");
    if (g_state.styleNursultanDiamond.load()) LOGI("  -> Nursultan Diamond");
    if (g_state.styleNursultanScanner.load()) LOGI("  -> Nursultan Scanner");
    if (g_state.styleGhostsClient.load())     LOGI("  -> Ghosts Client");
    if (g_state.styleGhostsCatlean.load())    LOGI("  -> Ghosts Catlean");
    if (g_state.styleWexsideSwords.load())    LOGI("  -> Wexside Swords");
    if (g_state.styleSimsCrystal.load())      LOGI("  -> Sims Crystal");
    if (g_state.styleJello.load())            LOGI("  -> Jello");
    if (g_state.styleRockstarCrystals.load()) LOGI("  -> Rockstar Crystals");
    if (g_state.styleRockstarChains.load())   LOGI("  -> Rockstar Chains");
    if (g_state.styleHitBubble.load())        LOGI("  -> HitBubble");
}

bool install() {
    if (g_installed.load(std::memory_order_acquire)) {
        LOGW("TargetESP already installed");
        return true;
    }

    LOGI("TargetESP install: hooks will be added after signatures for 1.26.60.4 are resolved");
    // TODO: signature scan + Hook for hurt/attack
    // For now we mark as installed so menu works and we can test config.
    g_installed.store(true, std::memory_order_release);
    return true;
}

void uninstall() {
    LOGI("TargetESP uninstall");
    g_hookHurt.reset();
    g_installed.store(false, std::memory_order_release);
}

} // namespace targetesp
